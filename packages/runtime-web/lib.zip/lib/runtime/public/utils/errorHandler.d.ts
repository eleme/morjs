export declare const catchComponentMethodsError: (target: any, errorHandler: any) => any;
