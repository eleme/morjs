export declare const combineValue: (array: any, key?: string) => {};
export declare const mergeExecution: (array: any, key?: string) => () => void;
