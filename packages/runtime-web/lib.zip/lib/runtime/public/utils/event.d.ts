export declare const Event: {
    emit(eventName: string, params?: {}): void;
};
