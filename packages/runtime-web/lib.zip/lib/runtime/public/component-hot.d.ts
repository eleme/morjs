export declare function MixinComponentForHot(componentInit: any, render: any): any;
export declare function forceCheckFunctionChanged(oldConfig: any, newConfig: any, name: any): void;
