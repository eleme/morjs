import React from 'react';
interface IState {
    prevProps: any;
    cachePrePropsAction: any;
    deriveDataFromProps: (props?: Record<string, any>) => void;
}
declare global {
    interface Window {
        $__USING_RAX__: boolean;
    }
}
export declare class KBComponent extends React.PureComponent<any, IState> {
    private cachePreDataAction;
    private updateDataQueue;
    private options;
    $id: any;
    private eventsInfo;
    protected _isMounted: any;
    componentConfig: any;
    protected $defaultProps: any;
    /**
     *
     * @param {*} props
     * @param {*} componentConfig
     * @param {isComplexComponents,isComponent} options
     */
    constructor(props: any, componentConfig: any, options: any);
    forceResetConfig(componentConfig: any): void;
    updatePageConfig(): void;
    onInit(): void;
    componentWillReceiveProps(props: any): any;
    static getDerivedStateFromProps(props: any, state: any): any;
    deriveDataFromProps(props: any): void;
    mergeProps(props: any): any;
    hasPropsChanged(props: any): boolean;
    mergePropsToComponent(props: any): void;
    componentDidMount(): void;
    didMount(): void;
    componentDidUpdate(): void;
    getPreSnapshot(source: any, cacheActions: any): any;
    didUpdate(): void;
    componentWillUnmount(): void;
    didUnmount(): void;
    getRenderData(): any;
    onRef(ref: any, value: any): boolean;
    getCompMethod(methodName: any): any;
    _bindMethod(method: any): any;
    /**
     * 动态绑定事件
     */
    _bindEvents(): void;
    _raiseEvent(e: any): void;
    registEvents(events: any, nodeId: any): void;
}
export {};
