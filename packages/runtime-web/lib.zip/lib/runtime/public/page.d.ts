import { KBComponent } from './component';
export declare function getQueryParams(url: any): {};
export declare class PageComponent extends KBComponent {
    private pageConfigJson;
    constructor(props: any, componentConfig: any, pageConfigJson: any, options: any);
    onInit(): void;
    didShow(): void;
    didMount(): void;
    setPageConfig(page?: any): void;
    onReady(): void;
    onPagePullDownRefresh(): void;
    onPageReachBottom(): void;
    onPageScroll(e: any): void;
    didUnmount(): void;
}
