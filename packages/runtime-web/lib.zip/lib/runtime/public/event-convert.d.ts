export default function (e: any): any;
