/// <reference types="mini-types" />
declare let currentApp: any;
declare function AppForWeb(options: tinyapp.AppOptions): void;
declare function __tigaProxyApp(): void;
