type IAxmlInfoType = {
    defaultRender: (this: Record<string, any>, data: Record<string, any>) => any;
    isComplexComponents?: boolean;
};
/**
 * 组件构造函数
 * @param axmlInfo 初始化函数
 */
export declare function Component(axmlInfo: IAxmlInfoType): any;
export declare function Page(axmlInfo: IAxmlInfoType, config: Record<string, any>): any;
export {};
