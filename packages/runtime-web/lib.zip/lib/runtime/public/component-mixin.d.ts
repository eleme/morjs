/**
 * 组件支持混入功能
 * @param {*} options
 */
export default function (options: any): any;
