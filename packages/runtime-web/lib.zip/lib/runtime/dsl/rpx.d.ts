/**
 * 设置根节点 font-size
 */
export declare function setRootFontSizeForRem(rootFontSize: number): void;
export declare function rpxToRem(rpxValue: number): string;
/**
 * 自动同步根节点的 font-size
 * 并设置 ROOT_VALUE
 */
export declare function autoSyncRootFontSize(updateOnResize?: boolean): void;
