declare const _default: {
    twoWayBinding(thisTarget: any): (valuePath: any, value: any) => void;
    /**
     *
     * @param {*} thisTarget 处理数据更改事件的对象
     * @param {*} valuePropName 绑定的属性名
     * @param {*} valuePath 属性名对应的表达式
     * @param {*} getValueFromEvent 对于有些组件，无法通过简单的判断来确定具体value的来源，那么可以通过getValueFromEvent 显式告知runtime
     * @param {*} otherEventCallBack 其他的事件回调函数。可以形成调用链
     */
    twoWayBindingMergeChangeEvent(thisTarget: any, valuePropName: any, valuePath: any, getValueFromEvent: any, otherEventCallBack: any): (event: any) => void;
};
export default _default;
