export declare function getEvent(funName: any, data: any, isCatch?: boolean): any;
export declare function bindThis(thistarget: any, func: any): {
    (): any;
    __name__: any;
};
export declare function registEvents(events: any, $data: any, nodeId: any): void;
