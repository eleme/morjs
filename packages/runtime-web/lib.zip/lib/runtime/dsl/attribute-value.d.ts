export declare function toJsonString(value: any, isDataSet?: boolean): any;
/**
 * 解析dataset value
 * @param {*} str
 */
export declare function parseDatasetValue(str: any): any;
