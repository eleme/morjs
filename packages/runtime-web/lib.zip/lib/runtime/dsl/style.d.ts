export declare function createStyle(style: string | Record<string, any>): Record<string, any>;
