export default function getForValue(value: any): any;
