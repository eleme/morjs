export default function ref(value: any, data: any): (ref: any) => void;
