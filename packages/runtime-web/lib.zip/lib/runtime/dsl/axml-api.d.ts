import type { KBComponent } from '../public/component';
import type TemplateManager from './template';
/**
 *
 * @param {*} tm templateManager
 */
export declare function axmlApi(tm: TemplateManager): {
    template(parent: KBComponent, tName: string, data: Record<string, any>): any;
};
