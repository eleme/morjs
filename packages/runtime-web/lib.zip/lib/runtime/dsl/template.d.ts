import { KBComponent } from '../public/component';
export default class TemplateManager {
    private templates;
    constructor();
    addAll(obj: Record<string, any>): void;
    renderTemplate(name: string, data: Record<string, any>, superComponent: KBComponent): any;
}
