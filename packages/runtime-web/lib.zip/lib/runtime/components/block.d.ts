import React from 'react';
export declare class Block extends React.PureComponent {
    render(): {};
}
