import React from 'react';
export declare class Slot extends React.PureComponent<{
    name: string;
    slots: React.ReactNode;
    $scopeKeys: string[];
}> {
    componentDidMount(): void;
    render(): any;
}
