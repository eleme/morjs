import IntersectionObserver from 'intersection-observer';
import MobileDetect from 'mobile-detect';
import { my } from './my';
import { appendApis } from './utils/extendApi';
export default my;
export { appendApis, 
/**
 * 暴露 MobileDetect 方便外部共用
 */
MobileDetect, 
/**
 * 暴露 IntersectionObserver 方便外部共用
 */
IntersectionObserver };
