declare const _default: {
    setClipboard({ text }: {
        text?: string;
    }): Promise<unknown>;
    getClipboard(): Promise<{
        text: string;
    }>;
};
export default _default;
