/**
 * Create fake copy action wrapper using a fake element.
 * @param {String} target
 * @param {Object} options
 * @return {String}
 * @source: copy from https://github.com/zenorocha/clipboard.js/blob/master/src/actions/copy.js
 */
export declare const copy: (value: any, options: any) => Promise<unknown>;
