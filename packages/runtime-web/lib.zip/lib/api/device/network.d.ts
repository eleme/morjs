declare const _default: {
    getNetworkType(): Promise<unknown>;
    onNetworkStatusChange(callback: any): void;
    offNetworkStatusChange(callback: any): void;
};
export default _default;
