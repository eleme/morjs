declare const _default: {
    makePhoneCall(params: PhoneOptions): void;
};
export default _default;
