declare const _default: {
    SDKVersion: string;
    getSystemInfo(): Promise<unknown>;
    getSystemInfoSync(): {
        model: string;
        pixelRatio: number;
        windowWidth: number;
        windowHeight: number;
        language: any;
        version: any;
        platform: string;
        system: string;
        titleBarHeight: number;
        statusBarHeight: number;
        screenWidth: number;
        screenHeight: number;
        brand: string;
        fontSizeSetting: number;
        app: string;
    };
};
export default _default;
