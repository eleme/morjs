declare const _default: {
    showTabBar(): Promise<unknown>;
    hideTabBar(): Promise<unknown>;
    showTabBarRedDot({ index }: {
        index: any;
    }): Promise<unknown>;
    hideTabBarRedDot({ index }: {
        index: any;
    }): Promise<unknown>;
    setTabBarBadge({ index, text }: {
        index: any;
        text: any;
    }): Promise<unknown>;
    removeTabBarBadge({ index }: {
        index: any;
    }): Promise<unknown>;
    setTabBarItem({ index, text, iconPath, selectedIconPath }: {
        index: any;
        text: any;
        iconPath: any;
        selectedIconPath: any;
    }): Promise<unknown>;
    setTabBarStyle({ color, selectedColor, backgroundColor, borderStyle }: {
        color: any;
        selectedColor: any;
        backgroundColor: any;
        borderStyle: any;
    }): Promise<unknown>;
};
export default _default;
