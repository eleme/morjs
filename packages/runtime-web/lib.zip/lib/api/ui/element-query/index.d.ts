import { updateRootView } from '../../global';
import IntersectionObserver from './intersection-observer';
declare const _default: {
    createIntersectionObserver(options?: any): IntersectionObserver;
    createSelectorQuery(): SelectorQuery;
    updateRootView: typeof updateRootView;
};
export default _default;
declare class SelectorQuery {
    private target;
    private execPromises;
    private fieldsPromise;
    select(selector: string): this;
    selectAll(selector: string): this;
    selectViewport(): this;
    boundingClientRect(): this;
    scrollOffset(): this;
    fields(config: any, callback: any): this;
    exec(callback: any): void;
}
