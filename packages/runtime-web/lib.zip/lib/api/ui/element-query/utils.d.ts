export declare const RECT_PROPERTIES: string[];
export declare const SCROLL_OFFSET_PROPERTIES: string[];
export declare const getProperties: (element: any, properties?: any[]) => any;
export declare const mapTarget: (target: any, callback: any) => any;
export declare const FIELD_CONFIG_METHODS_MAP: {
    id: (el: HTMLElement) => {
        id: string;
    };
    rect: (el: HTMLElement) => any;
    size: (el: HTMLElement) => any;
    scrollOffset: (el: HTMLElement) => any;
    node: (el: HTMLElement) => {
        node: HTMLElement;
    };
    computedStyle: (el: HTMLElement, keys: Array<string>) => {};
    dataset: (el: HTMLElement) => {
        dataset: {};
    };
};
