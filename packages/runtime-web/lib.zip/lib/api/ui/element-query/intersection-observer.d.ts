/**
 * doc: https://opendocs.alipay.com/mini/api/intersectionobserver
 */
declare class LocalIntersectionObserver {
    /**
     * 初始的相交比例，如果调用时检测到的相交比例与这个值不相等且达到阈值，则会触发一次监听器的回调函数。默认值为 0。
     */
    readonly initialRatio: number;
    /**
     * 一个数值数组，包含所有阈值。默认值为 [0]。
     */
    readonly thresholds: number | number[];
    /**
     * 是否同时观测多个目标节点（而非一个），如果设为 true ，observe 的 targetSelector 将选中多个节点（注意：同时选中过多节点将影响渲染性能）。默认值为 false。
     */
    readonly selectAll: boolean;
    private intersectionObserver;
    private callBackInfos;
    private targetAppearedInfos;
    private sortedThresholds;
    constructor({ thresholds, initialRatio, selectAll }?: {
        thresholds?: number;
        initialRatio?: number;
        selectAll?: boolean;
    });
    get root(): Document | Element;
    private _observerCallBack;
    relativeToViewport(margins?: any): this;
    private convertToRootMargin;
    relativeTo(selector: string | HTMLElement, margins?: any): this;
    observe(target: string | HTMLElement | HTMLElement[], callback: () => void): this;
    unobserve(target: string | HTMLElement | HTMLElement[]): void;
    /**
     * 停止监听。回调函数将不再触发。
     */
    disconnect(): void;
}
export default LocalIntersectionObserver;
