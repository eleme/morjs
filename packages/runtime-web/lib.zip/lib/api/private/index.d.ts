import Event from './Event';
declare const _default: {
    $tigaEvent: Event;
    $pageOnReadyCall: (callback: any) => Promise<unknown>;
};
export default _default;
