export declare const getEventName: (eventName: any) => string;
export declare const PAGE_ON_READY = "pageOnReady";
export default class Event {
    private callbackMap;
    on(eventName: any, callback: any): void;
    emit(eventName: any, params: any): void;
    clear(): void;
    removeAllCallbacks(eventName: any): void;
    remove(eventName: any, callback: any): void;
    size(eventName: any): any;
    once(eventName: any, callback: any): void;
}
