export declare const setHeader: (xhr: any, header: any) => void;
/**
 * 将 blob url 转化为文件
 * @param {string} url 要转换为blob的url
 * @returns {Promise<File>}
 */
export declare const convertObjectUrlToBlob: (url: any) => Promise<Blob>;
export declare const NETWORK_TIMEOUT = 30000;
