export interface IPromisePlus extends Promise<any> {
    onProgressUpdate: () => void;
    abort: () => void;
}
/**
 * 将本地资源上传到服务器。
 * @param {Object} object 参数
 * @param {string} object.url 开发者服务器地址
 * @param {string} object.filePath 要上传文件资源的路径
 * @param {Object} [object.header] HTTP 请求 Header，Header 中不能设置 Referer
 * @param {Object} [object.formData] HTTP 请求中其他额外的 form data
 * @param {string} [object.fileName] 上传的文件名
 * @param {string} [object.name] 文件对应的 key
 * @param {boolean} [object.withCredentials] 上传xhr的withCredentials值
 * @returns {UploadTask}
 */
declare const uploadFile: ({ url, filePath, header, formData, fileName, name, withCredentials }: my.IUploadFileOptions) => IPromisePlus;
export default uploadFile;
