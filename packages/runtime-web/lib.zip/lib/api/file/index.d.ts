declare const _default: {
    uploadFile: ({ url, filePath, header, formData, fileName, name, withCredentials }: my.IUploadFileOptions) => import("./uploadFile").IPromisePlus;
};
export default _default;
