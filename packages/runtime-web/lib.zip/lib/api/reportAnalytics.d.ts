declare const _default: {
    reportAnalytics(): void;
};
export default _default;
