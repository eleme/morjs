declare const _default: {
    navigateToOutside(options: any): void;
    getStartupPrams(options: any): void;
};
export default _default;
