declare const _default: {
    createMapContext(id: any): any;
    getMapInfo({ success }: {
        success: any;
    }): void;
};
export default _default;
