export declare function onAppShow(callback: any): void;
export declare function offAppShow(callback: any): void;
export declare function onAppHide(callback: any): void;
export declare function offAppHide(callback: any): void;
