import 'whatwg-fetch';
declare const _default: {
    closeSocket(): Promise<void>;
    connectSocket(): Promise<void>;
    downloadFile(): Promise<my.IDownloadFileSuccessResult>;
    offSocketClose(): void;
    offSocketMessage(): void;
    request(options: any): Promise<Record<string, any>>;
};
export default _default;
