declare const _default: {
    getLocation(): Promise<unknown>;
    chooseLocation(): void;
    openLocation(): void;
};
export default _default;
