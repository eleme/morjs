interface ParameterOptions {
    name?: string;
    para?: string;
    wrong: object;
    correct: string;
}
export declare function getParameterError({ name, para, correct, wrong }: ParameterOptions): string;
export declare function shouldBeObject(target: any): {
    res: boolean;
    msg?: undefined;
} | {
    res: boolean;
    msg: string;
};
export declare const createCallbackManager: () => {
    add: (opt: any) => void;
    trigger: (...args: any[]) => void;
    remove: (opt: any) => void;
};
export declare const pageOnReadyCallApi: (my: Record<string, any>) => void;
export declare const getPageAsKey: () => string;
export declare const appendQueryToUrl: (url?: string, query?: {}) => string;
export declare const convertBlobToBase64: (blob: any) => Promise<unknown>;
export declare const wait: (millisecond?: number) => Promise<unknown>;
export declare const isObject: (param: any) => boolean;
export declare const isFunction: (param: any) => boolean;
export {};
