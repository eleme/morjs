/**
 * 默认是否允许覆盖全局对象中已有的 API
 */
export declare const DEFAULT_API_NO_CONFLICT: boolean;
export declare function convertApis(apis: Record<string, any>): {};
export declare function appendApis(apiObj: Record<string, any>, noConflict?: boolean): void;
