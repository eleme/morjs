declare const _default: ({ latitude, longitude }: {
    latitude: any;
    longitude: any;
}) => {
    latitude: any;
    longitude: any;
};
export default _default;
