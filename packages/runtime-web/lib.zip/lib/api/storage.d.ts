declare const _default: {
    setStorage(options: my.ISetStorageOptions): Promise<void>;
    getStorage(options: my.IGetStorageOptions): Promise<string | Readonly<Record<string, any>>>;
    removeStorage(options: my.IRemoveStorageOptions): Promise<void>;
    getStorageInfo(): Promise<Record<string, any>>;
    clearStorage(): void;
    setStorageSync(option: my.ISetStorageSyncOptions): void;
    getStorageSync(option: my.IGetStorageSyncOptions): any;
    removeStorageSync({ key }: my.IRemoveStorageSyncOptions): void;
    getStorageInfoSync(): Record<string, any>;
    clearStorageSync(): void;
};
export default _default;
