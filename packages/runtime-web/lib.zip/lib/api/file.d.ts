declare const _default: {
    getFileInfo(): Promise<my.IGetFileInfoSuccessResult>;
    getSavedFileInfo(): Promise<my.IGetSavedFileInfoSuccessResult>;
    getSavedFileList(): Promise<my.IGetSavedFileListSuccessResult>;
    openDocument(): Promise<my.IGetSavedFileListSuccessResult>;
    removeSavedFile(): Promise<void>;
    saveFile(): Promise<my.ISaveFileSuccessResult>;
};
export default _default;
