declare const _default: {
    createVideoContext(id: any): any;
};
export default _default;
