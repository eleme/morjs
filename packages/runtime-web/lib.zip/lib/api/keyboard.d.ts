declare const _default: {
    /**
     * 隐藏键盘
     */
    hideKeyboard(): void;
};
export default _default;
