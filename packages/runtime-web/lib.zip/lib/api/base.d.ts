type IAnyFunc = (...args: unknown[]) => any;
export default function generateBaseAPI(api: Record<string, any>): {
    call(apiName: string, params: any, success: IAnyFunc, fail: IAnyFunc, complete: IAnyFunc): any;
    canIUse(param?: string): boolean;
    SDKVersion: string;
};
export {};
