export declare function getGlobalObject(): string;
export declare const my: Record<string, any>;
