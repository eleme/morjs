declare const _default: {
    compressImage(): Promise<my.ICompressImageSuccessResult>;
    /**
     * 从本地相册选择图片。
     * @param {Object} options 参数
     * @param {number} [options.count=1] 最多可以选择的图片张数
     */
    chooseImage(options: PromiseOptions<my.IChooseImageOptions>): Promise<my.IChooseImageSuccessResult>;
    getImageInfo(options: PromiseOptions<my.IGetImageInfoOptions>): Promise<my.IGetImageInfoSuccessResult>;
    saveImage(): Promise<void>;
};
export default _default;
