declare class CustomCache {
    _cache: {};
    set(key: any, value: any): void;
    get(key: any): any;
}
declare const _default: CustomCache;
export default _default;
