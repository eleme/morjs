import { History } from 'history';
export declare let mode: string;
export declare let history: History;
export declare function setHistoryMode(historyMode: string, basename: string): void;
