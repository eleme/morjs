import { ILocation } from './types';
export declare function setBaseName(path: string): void;
export declare function setCustomRoutes(routes: Record<string, string>[]): void;
export declare function setPages(pageList: any[]): void;
export declare const getCustomUrl: (url: string) => string;
export declare const addLeadingSlash: (str: string | undefined) => string;
export declare const removeLeadingSlash: (str: string) => string;
export declare const getPathAndOptions: (location: ILocation) => {
    route: string;
    path: string;
    options: Record<any, any>;
};
/**
 * 小程序页面的options
 */
export declare const getOptions: (location?: ILocation) => Record<any, any>;
/**
 * 获取当前url的参数
 */
export declare function getQueryParams(url: any): Record<any, any>;
/**
 * h5 url的 pathname 和 search
 */
export declare const getPathNameAndSearch: (location: ILocation) => {
    pathName: string;
    search: string;
};
/**
 * route，小程序route,例如 pages/index/index
 */
export declare const getRoute: (location?: ILocation) => string;
/**
 * pageId，标识唯一page
 */
export declare const getPageId: (location?: ILocation) => string;
/**
 * 小程序完整地址, 例如 pages/index/index?test=1
 */
export declare const getOriginUrl: (location: ILocation) => string;
/**
 * 小程序启动参数
 */
export declare const getRelaunchOptions: () => {
    query: Record<any, any>;
    referrerInfo: {};
};
/**
 * 根据页面相对路径，计算出绝对路径 '../swiper/index' => 'pages/swiper/index'
 * @param {String} relativePath 相对路径
 * @returns 绝对路径
 */
export declare const getAbsolutePath: (relativePath: string) => string;
