export declare function initLayout(rootElement: HTMLElement): void;
