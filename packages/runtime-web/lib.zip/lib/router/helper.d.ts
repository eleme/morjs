export declare const TAB_BAR_PATH_CACHE_KEY = "tabBarPath";
export declare const cacheTabBarPath: (config: any) => void;
export declare const isTabBarPage: (path: any) => any;
