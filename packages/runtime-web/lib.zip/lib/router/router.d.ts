import './api';
import { IRouterChangeDetail, IRouterConfig } from './types';
export declare function batchUnloadPage(delta: number): void;
export declare function unloadPageByCondition(callback: any): void;
export declare function tigaRouterChangeHandler(e: {
    detail: IRouterChangeDetail;
}, component: string): void;
export declare function createRouter(config: IRouterConfig, element: HTMLElement): void;
