import { IRouterConfig } from './types';
export declare function initTabBar(config: IRouterConfig): void;
