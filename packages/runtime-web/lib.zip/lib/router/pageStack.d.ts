import { IPage } from './types';
export declare const pageStack: IPage[];
export declare function getCurrentPages(): IPage[];
export declare function getCurPage(): IPage;
