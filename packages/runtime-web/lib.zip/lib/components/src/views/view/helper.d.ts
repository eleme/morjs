export declare const findScrollParent: (element: any) => any;
export declare const getElementVisibleRatio: (element: Element) => string | 1 | 0;
