import { BaseElement } from '../../baseElement';
export default class View extends BaseElement {
    ['disable-scroll']: boolean;
    static get styles(): import("lit-element").CSSResult;
    private needBindAppear;
    private isFirstUpdatedInvoked;
    private isWatchTouchMove;
    private listener;
    addEventListener(type: any, callback: any, options?: any): void;
    firstUpdated(): void;
    private scrollParent;
    getScrollParent(): any;
    private lastTrigger;
    private hasAppeared;
    watchTouchMove(): void;
    disconnectedCallback(): void;
    preventScroll(): void;
    releaseScroll(): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    render(): import("lit-element").TemplateResult;
}
