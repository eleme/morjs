import { LitElement } from 'lit-element';
export default class SwiperItem extends LitElement {
    render(): import("lit-element").TemplateResult;
}
