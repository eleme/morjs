interface KEY {
    INDICATOR_DOTS: any;
    INDICATOR_COLOR: any;
    INDICATOR_ACTIVE_COLOR: any;
    AUTOPLAY: any;
    CURRENT: any;
    DURATION: any;
    INTERVAL: any;
    CIRCULAR: any;
    VERTICAL: any;
    PREVIOUS_MARGIN: any;
    NEXT_MARGIN: any;
    CLASS: any;
    DISABLE_TOUCH: any;
    TOUCH_ANGLE: any;
    SWIPE_RATIO: any;
}
type Attributes = {
    [P in keyof KEY]?: string;
};
type Properties = {
    [P in keyof KEY]?: symbol;
};
export declare const attributes: Attributes;
export declare const properties: Properties;
export {};
