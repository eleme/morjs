import { LitElement } from 'lit-element';
export default class TigaSwiper extends LitElement {
    swiperId: number;
    elementChildren: any[];
    static get properties(): {
        [x: symbol]: {
            converter: {
                fromAttribute(value: any): boolean;
            };
            attribute: string;
            type?: undefined;
        } | {
            type: StringConstructor;
            attribute: string;
            converter?: undefined;
        } | {
            type: NumberConstructor;
            attribute: string;
            converter?: undefined;
        };
    };
    swiper: any;
    swiperWrapper: any;
    realIndex: any;
    updating: boolean;
    constructor();
    initProperties(): void;
    createRenderRoot(): this;
    connectedCallback(): void;
    firstUpdated: () => Promise<void>;
    loadScript: () => Promise<unknown>;
    isElementNode: (element: HTMLElement) => boolean;
    overwriteDomOperation(): void;
    updated(changedProperties: any): void;
    watchAutoPlay(): void;
    watchCurrent(): void;
    watchDuration(): void;
    watchInterval(): void;
    disconnectedCallback(): void;
    render(): import("lit-element").TemplateResult;
}
