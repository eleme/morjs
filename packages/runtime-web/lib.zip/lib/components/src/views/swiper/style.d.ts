export declare const styles: import("lit-element").CSSResult;
