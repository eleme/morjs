import { BaseElement } from '../baseElement';
export default class MovableArea extends BaseElement {
    static get styles(): import("lit-element").CSSResult;
    render(): import("lit-element").TemplateResult;
}
