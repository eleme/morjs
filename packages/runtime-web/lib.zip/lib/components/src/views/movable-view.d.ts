import { BaseElement } from '../baseElement';
/**
 * 可移动的视图容器，在页面中可以拖拽滑动。
 * movable-view 必须在 movable-area 组件中，并且必须是直接子节点，否则不能移动。
 */
export default class MovableView extends BaseElement {
    static get styles(): import("lit-element").CSSResult;
    /**
     * 定义 x 轴方向的偏移，会换算为 left 属性，如果 x 的值不在可移动范围内，会自动移动到可移动范围。
     */
    x: number;
    /**
     * 定义 y 轴方向的偏移，会换算为 top 属性，如果 y 的值不在可移动范围内，会自动移动到可移动范围。
     */
    y: number;
    /**
     * 超过可移动区域后，movable-view 是否还可以移动。
     */
    ['out-of-bounds']: boolean;
    /**
     * movable-view 的移动方向，属性值有 all、vertical、horizontal、none。
     */
    direction: string;
    connectedCallback(): void;
    onTouchStart: (e: TouchEvent) => void;
    private canMove;
    private lastPoint;
    onMouseMove: (e: MouseEvent) => void;
    onTouchMove: (e: TouchEvent) => void;
    onMove(point: {
        clientX: any;
        clientY: any;
    }): void;
    onTouchEnd: (e: TouchEvent) => void;
    moveEnd(): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    private position;
    private updatePosition;
    render(): import("lit-element").TemplateResult;
}
