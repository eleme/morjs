import { LitElement } from 'lit-element';
export default class ScrollView extends LitElement {
    private _isFixed;
    private observer;
    static get styles(): import("lit-element").CSSResult;
    static get properties(): {
        [x: symbol]: {
            converter: {
                fromAttribute(value: any): boolean;
            };
            attribute: string;
            type?: undefined;
        } | {
            type: NumberConstructor;
            attribute: string;
            converter?: undefined;
        };
    };
    constructor();
    initProperties(): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    watchScrollView(): void;
    unWatchScrollView(): void;
    connectedCallback(): void;
    disconnectedCallback(): void;
    private preventScroll;
    private canHandleReachBottomY;
    private canHandleReachTopY;
    private canHandleReachBottomX;
    private canHandleReachTopX;
    private onScroll;
    private _scrollIntoView;
    render(): import("lit-element").TemplateResult;
}
