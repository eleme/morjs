interface KEY {
    DISABLE_SCROLL: any;
    SCROLL_TOP: any;
    SCROLL_LEFT: any;
    SCROLL_INTO_VIEW: any;
    UPPER_THRESHOLD: any;
    LOWER_THRESHOLD: any;
    SCROLL_X: any;
    SCROLL_Y: any;
    TRAP_SCROLL: any;
    SCROLL_WITH_ANIMATION: any;
}
type Attributes = {
    [P in keyof KEY]?: string;
};
type Properties = {
    [P in keyof KEY]?: symbol;
};
export declare const attributes: Attributes;
export declare const properties: Properties;
export {};
