export default function polyfill(): void;
