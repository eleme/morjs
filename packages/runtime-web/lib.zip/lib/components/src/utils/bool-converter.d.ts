declare const _default: {
    fromAttribute(value: any): boolean;
};
export default _default;
