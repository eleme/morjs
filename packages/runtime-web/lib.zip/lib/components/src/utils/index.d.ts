/// <reference types="node" />
/**
 * 设备是否支持触摸事件
 */
export declare function supportTouch(): boolean;
export declare function uuid(): string;
export declare function isMobile(): boolean;
export declare function colorReverse(oldColor: any): string;
export declare const isPureWhite: (color?: string) => boolean;
export declare const isIos: () => boolean;
export declare const addFocusToInputTypeElement: (node: any) => void;
export declare const getPropertiesByAttributes: (keys?: any[]) => {};
export declare const defineElement: (name: any, element: any) => void;
export declare const converterForPx: {
    fromAttribute: (value?: string) => string;
};
export declare function shouldEnableFor(feature: boolean | string[] | ((pagePath: string) => boolean), pagePath: string): boolean | undefined;
export declare const getCurrentPagePath: () => any;
export declare const requestAnimationFrame: (callback: any) => number | NodeJS.Timeout;
