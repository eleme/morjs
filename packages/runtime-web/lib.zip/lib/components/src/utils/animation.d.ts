export declare const KEY_ANIMATION = "animation";
export declare function parseAnimation2Style(param: any, context: any): Generator<Promise<any>, void, unknown>;
export declare const autoRun: (fn: any, callback: any) => void;
