declare const _default: {
    fromAttribute(value: any): any;
};
export default _default;
