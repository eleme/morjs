export default function (options: any): void;
