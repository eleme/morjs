export declare function makeCancelPromise<T>(p: Promise<T>, onCancel?: () => void): CancelPromise;
export declare function isCancelPromise(p: CancelPromise): boolean;
export declare function isCancel(err: any): boolean;
