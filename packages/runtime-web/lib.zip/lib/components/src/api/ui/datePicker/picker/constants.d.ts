export declare const FORMATE_MAP: string[];
export declare const PROPERTY: {
    YEAR: string;
    MONTH: string;
    DAY: string;
    HOUR: string;
    MINUTE: string;
};
export declare const NEED_DEFAULT_VALUE = "needed";
