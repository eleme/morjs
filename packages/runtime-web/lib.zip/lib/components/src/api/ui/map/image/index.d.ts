import { LitElement } from 'lit-element';
export default class Image extends LitElement {
    static get styles(): import("lit-element").CSSResult;
    id: any;
    width: any;
    height: any;
    left: number;
    top: number;
    right: any;
    bottom: any;
    ['background-color']: string;
    padding: number;
    ['padding-left']: number;
    ['padding-top']: number;
    ['padding-right']: number;
    ['padding-bottom']: number;
    ['border-color']: string;
    ['border-radius']: number;
    ['border-width']: number;
    src: any;
    placeholder: any;
    styleObject: {};
    onStyleChange(name: any, value: any): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    connectedCallback(): void;
    render(): import("lit-element").TemplateResult;
}
