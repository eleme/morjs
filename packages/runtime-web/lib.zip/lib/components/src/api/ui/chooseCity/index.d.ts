import './chooseCity';
declare const _default: {
    chooseCity(options: any): void;
    onLocatedComplete(options: any): void;
    setLocatedCity(options: any): void;
    regionPicker(options: any): void;
};
export default _default;
