import './picker/index';
declare const _default: {
    datePicker(attributes: any): Promise<unknown>;
};
export default _default;
