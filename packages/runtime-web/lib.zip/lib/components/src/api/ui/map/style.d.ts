declare const _default: import("lit-element").CSSResult;
export default _default;
export declare function handleStyleText(styleObject: any): string;
export declare function collectStyleObject(self: any, name: any, value: any): void;
export declare const onCommonStyleChange: (self: any, name: any, value?: number) => void;
