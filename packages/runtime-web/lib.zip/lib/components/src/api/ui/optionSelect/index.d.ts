import './common-modal/index';
import './option-select/index';
declare const _default: {
    optionsSelect(attributes: any): Promise<unknown>;
};
export default _default;
