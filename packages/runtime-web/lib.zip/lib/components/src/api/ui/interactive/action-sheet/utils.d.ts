export declare const fixedBody: (document: any) => void;
export declare const looseBody: (document: any) => void;
export declare const take: (array: any, property: any) => any[];
export declare const getValueByIndex: (array: any, index: any) => any;
export declare const formateNum: (num: any) => any;
export declare const isIos: () => boolean;
