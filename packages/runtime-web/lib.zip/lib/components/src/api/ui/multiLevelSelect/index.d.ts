import './modal/index';
import './select/index';
declare const _default: {
    multiLevelSelect(attributes: any): Promise<unknown>;
};
export default _default;
