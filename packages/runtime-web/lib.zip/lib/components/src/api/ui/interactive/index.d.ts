import './action-sheet/index';
import './alert';
import './confirm/index';
import './loading';
import './preview-image/index';
import './prompt/index';
import './toast/index';
declare const _default: {
    previewImage(options: any): Promise<void>;
    alert({ title, content, buttonText }: {
        title: any;
        content: any;
        buttonText: any;
    }): Promise<unknown>;
    showLoading({ content, delay }: {
        content: any;
        delay: any;
    }): void | Promise<void>;
    hideLoading(): Promise<unknown>;
    showToast({ content, type, duration }: {
        content: any;
        type: any;
        duration?: number;
    }): Promise<unknown>;
    hideToast(): Promise<unknown>;
    confirm(attributes: any): Promise<unknown>;
    prompt(attributes: any): Promise<unknown>;
    showActionSheet(attributes: any): Promise<unknown>;
};
export default _default;
