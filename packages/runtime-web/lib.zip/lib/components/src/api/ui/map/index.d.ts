declare const _default: {
    createMapContext(id: any): CreateMapContext;
    getMapInfo(): Promise<{
        is3d: boolean;
        isSupportAnim: boolean;
        sdkName: string;
        sdkVersion: string;
        isSupportOversea: boolean;
        needStyleV7: boolean;
    }>;
};
export default _default;
declare class CreateMapContext {
    private map;
    constructor(mapId: any);
    calculateDistance(): void;
    changeMarkers(): void;
    clearRoute(): any;
    gestureEnable(): void;
    getCenterLocation(options: any): any;
    getMapProperties(options: any): void;
    getRegion(): void;
    moveToLocation(options: any): any;
    showRoute(options: any): any;
    showsCompass(): void;
    showsScale(options: any): any;
    smoothMoveMarker(): void;
    smoothMovePolyline(): void;
    translateMarker(): void;
    updateComponents(options: any): any;
    getRotate(options: any): any;
    getScale(options: any): any;
    getSkew(options: any): any;
    includePoints(options: any): any;
    mapToScreen(): void;
    screenToMap(): void;
    polygonContainsPoint(): void;
    setCenterOffset(): void;
    setMapType(): void;
    smoothMoveMarke(): void;
}
