import { CreatePatternRepeatType } from './types';
export default class Canvas {
    private ctx;
    private canvas;
    private canvasWidth;
    private canvasHeight;
    private actions;
    private drawActionGroup;
    private devicePixelRatio;
    static create(canvasId: string): Canvas;
    constructor(canvasId: string);
    private getSetUpperName;
    initStyleProperties(): void;
    initPushAction(): void;
    setFontSize(fontSize?: number): void;
    /**
     * @param args
     * imageResource: string, x: number, y: number, width: number = 200, height: number = 200
     */
    drawImage(...args: any[]): void;
    set font(value: any);
    createCircularGradient(x: number, y: number, r: number): CanvasGradient;
    createLinearGradient(x0: number, y0: number, x1: number, y1: number): CanvasGradient;
    createPattern(imageResource: string, repeat: CreatePatternRepeatType): Promise<CanvasPattern>;
    measureText(text: string): TextMetrics;
    parseDrawActions(): Promise<any>[];
    addActionsMark(): void;
    createDrawActionGroup(reserve: any): void;
    draw(reserve: any, callback: any): void;
    private toDrawActions;
    private _drawImage;
    private _setFontSize;
    private _setShadow;
    clearActions(): void;
    clear(): void;
    clearCtxStyle(): void;
}
