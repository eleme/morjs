declare const _default: {
    alphabet: string[];
    cityList: {
        idx: string;
        cities: {
            id: number;
            name: string;
            pinyin: string;
            latitude: number;
            longitude: number;
            districtCode: number;
        }[];
    }[];
};
export default _default;
