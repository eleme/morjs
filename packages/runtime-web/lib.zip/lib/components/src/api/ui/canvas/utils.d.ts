export declare function upperFirstChar(str: any): any;
export declare function randomUuid(): string;
export declare function getImage(imageResource: any): Promise<CanvasImageSource>;
