import Animation from './animation';
declare const _default: {
    createAnimation(config: any): Animation;
};
export default _default;
