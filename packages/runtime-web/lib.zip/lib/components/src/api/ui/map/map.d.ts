import { BaseElement } from '../../../baseElement';
export default class Map extends BaseElement {
    mapId: string;
    fitViewAvoid: number[];
    constructor();
    getDefaultProps(): void;
    connectedCallback(): void;
    createRenderRoot(): this;
    disconnectedCallback(): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    getMapConfig(): Record<string, any>;
    loadAMapSdk(callback: any): void;
    drawMap(res: any): void;
    getEvent(): any;
    emitRegionChange(detail: any): void;
    __handleRegionChange(): void;
    showLocation(): void;
    __drawPolyline(pl?: any): void;
    __drawPolygon(): void;
    __drawCircles(): void;
    __drawControls(): void;
    getMarkerOptions(item: any): {
        content: string;
        anchor: string;
        offset: any;
    } | {
        content: string;
        offset: any;
        anchor?: undefined;
    };
    getMarkerCallout(item: any): {
        longitude: any;
        latitude: any;
        anchor: string;
        offset: any;
        content: string;
    };
    findInfoWindowMarker(markers: any): any;
    __drawMarkers(mks?: any): void;
    __drawIncludePoints(ip?: any): void;
    getHexAlpha(color: any): {
        hex: any;
        alpha: number;
    };
    getCenterLocation(options: any): void;
    moveToLocation(options: any): void;
    getRotate(options: any): void;
    getScale(options: any): void;
    getSkew(options: any): void;
    showsScale(options: any): void;
    showRoute(options: any): void;
    trafficEnabledShow(): void;
    trafficEnabledHide(): void;
    clearRoute(): void;
    clearMarkers(): void;
    clearPolyline(): void;
    clearPolygon(): void;
    clearCircles(): void;
    clearControls(): void;
    clearIncludePoints(): void;
    updateComponent(options: any): void;
    static get styles(): import("lit-element").CSSResult;
    static get properties(): {
        [x: symbol]: {
            type: NumberConstructor;
            attribute: string;
            converter?: undefined;
        } | {
            converter: {
                fromAttribute(value: any): any;
            };
            attribute: string;
            type?: undefined;
        } | {
            type: StringConstructor;
            attribute: string;
            converter?: undefined;
        };
    };
    map: any;
    drawed: boolean;
    markers: any[];
    infoWindow: any;
    polyline: any[];
    polygon: any[];
    circles: any[];
    controls: any[];
    includePoints: any[];
    scale: any;
    walking: any;
    tileLayer: any;
    rootMapElement: HTMLDivElement;
    render(): import("lit-element").TemplateResult;
}
