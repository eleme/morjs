export declare const stylePropertyMap: {
    fillStyle: string;
    strokeStyle: string;
    globalAlpha: number;
    lineWidth: number;
    lineCap: string;
    lineJoin: string;
    miterLimit: number;
    textBaseline: string;
    lineDashOffset: number;
    textAlign: string;
    globalCompositeOperation: string;
};
export declare const styleProperties: string[];
export declare const toolsProperties: string[];
