interface KEY {
    LONGITUDE: any;
    LATITUDE: any;
    SCALE: any;
    SKEW: any;
    ROTATE: any;
    MARKERS: any;
    POLYLINE: any;
    CIRCLES: any;
    CONTROLS: any;
    POLYGON: any;
    SHOW_LOCATION: any;
    INCLUDE_POINTS: any;
    INCLUDE_PADDING: any;
    GROUND_OVERLAYS: any;
    TILE_OVERLAY: any;
    CUSTOM_MAP_STYLE: any;
    PANELS: any;
    SETTING: any;
    ID: any;
    AMAP_KEY: any;
    AMAP_SDK: any;
    AMAP_VERSION: any;
    AMAP_STYLE: any;
    AMAP_FITVIEW_AVOID: any;
}
type Attributes = {
    [P in keyof KEY]?: string;
};
type Properties = {
    [P in keyof KEY]?: symbol;
};
export declare const attributes: Attributes;
export declare const properties: Properties;
export {};
