import CanvasCtx from './canvas-context';
declare const _default: {
    createCanvasContext(id: string): CanvasCtx;
};
export default _default;
