export declare const fixedBody: (document: any) => void;
export declare const looseBody: (document: any) => void;
export declare const isIos: () => boolean;
