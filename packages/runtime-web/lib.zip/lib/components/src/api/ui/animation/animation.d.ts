export default class Animation {
    result: any[];
    currentStep: any;
    initConfig: any;
    constructor(config: any);
    _generateStep(config: any): {
        animation: any[];
        config: {
            duration: any;
            timeFunction: any;
            delay: any;
            transformOrigin: any;
        };
    };
    _mount(property: any, callback: any): this;
    _push(property: any, value: any): void;
    _hasAnimation(): boolean;
    step(config: any): this;
    export(): any[];
}
