export declare const isContain: (format: any) => (param: any) => boolean;
export declare const onlyTime: (format: any) => boolean;
export declare const getListValue: (obj: any, index: any) => number;
export declare const buildResult: ({ year, month, day, hour, minute, format }: {
    year: any;
    month: any;
    day: any;
    hour: any;
    minute: any;
    format: any;
}) => string;
export declare const generateList: (start: any, end: any, unit?: string) => any[];
export declare const generateYears: ({ start, end, current }: {
    start: any;
    end: any;
    current: any;
}) => {
    list?: undefined;
    currentIndex?: undefined;
} | {
    list: any[];
    currentIndex: number;
};
export declare const generateMonths: ({ start, end, current }: {
    start: any;
    end: any;
    current: any;
}) => {
    list?: undefined;
    currentIndex?: undefined;
} | {
    list: any[];
    currentIndex: number;
};
export declare const getDays: (year: any, month: any) => number;
export declare const generateDays: ({ start, end, current }: {
    start: any;
    end: any;
    current: any;
}) => {
    list?: undefined;
    currentIndex?: undefined;
} | {
    list: any[];
    currentIndex: number;
};
export declare const generateHours: ({ start, end, current }: {
    start: any;
    end: any;
    current: any;
}) => {
    list?: undefined;
    currentIndex?: undefined;
} | {
    list: any[];
    currentIndex: number;
};
export declare const generateMinutes: ({ start, end, current }: {
    start: any;
    end: any;
    current: any;
}) => {
    list?: undefined;
    currentIndex?: undefined;
} | {
    list: any[];
    currentIndex: number;
};
export declare const getList: ({ currentDate, startDate, endDate, format }: {
    currentDate: any;
    startDate: any;
    endDate: any;
    format: any;
}) => () => {
    years: {
        list?: undefined;
        currentIndex?: undefined;
    } | {
        list: any[];
        currentIndex: number;
    };
    getYears: (index: any) => {
        list?: undefined;
        currentIndex?: undefined;
    } | {
        list: any[];
        currentIndex: number;
    };
    months: {
        list?: undefined;
        currentIndex?: undefined;
    } | {
        list: any[];
        currentIndex: number;
    };
    getMonths: (index: any) => {
        list?: undefined;
        currentIndex?: undefined;
    } | {
        list: any[];
        currentIndex: number;
    };
    days: {
        list?: undefined;
        currentIndex?: undefined;
    } | {
        list: any[];
        currentIndex: number;
    };
    getDays: (index: any) => {
        list?: undefined;
        currentIndex?: undefined;
    } | {
        list: any[];
        currentIndex: number;
    };
    hours: {
        list?: undefined;
        currentIndex?: undefined;
    } | {
        list: any[];
        currentIndex: number;
    };
    getHours: (index: any) => {
        list?: undefined;
        currentIndex?: undefined;
    } | {
        list: any[];
        currentIndex: number;
    };
    minutes: {
        list?: undefined;
        currentIndex?: undefined;
    } | {
        list: any[];
        currentIndex: number;
    };
    getMinutes: (index: any) => {
        list?: undefined;
        currentIndex?: undefined;
    } | {
        list: any[];
        currentIndex: number;
    };
};
