export declare const ModalStyles: import("lit-element").CSSResult;
