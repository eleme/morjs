import { BaseElement } from '../../../baseElement';
export default class Canvas extends BaseElement {
    static get styles(): import("lit-element").CSSResult;
    /**
     * 组件唯一标识符
     */
    id: string;
    /**
     * 样式名
     */
    class: string;
    /**
     * 宽度 默认值：300px
     */
    width: string;
    /**
     * 高度 默认值：225px
     */
    height: string;
    /**
     * 禁止屏幕滚动以及下拉刷新
     */
    ['disable-scroll']: boolean;
    /**
     * 组件值，选中时 change 事件会携带的 value。
     */
    onChange: string;
    connectedCallback(): void;
    disconnectedCallback(): void;
    _handleClick(e: any): void;
    render(): import("lit-element").TemplateResult;
}
