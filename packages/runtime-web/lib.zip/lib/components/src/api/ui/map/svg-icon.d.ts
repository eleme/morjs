export declare const invertedTriangle: (width?: string, height?: string, color?: string) => string;
export declare const arrow: (width?: string, height?: string, color?: string) => string;
