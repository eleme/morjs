declare class WebViewContext {
    private webview;
    constructor(webviewId: any);
    postMessage(data: any): void;
}
declare const _default: {
    createWebViewContext(webviewId: any): WebViewContext;
};
export default _default;
