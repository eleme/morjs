import { BaseElement } from '../baseElement';
export default class WebView extends BaseElement {
    timeId: any;
    maxTimeCount: number;
    static get styles(): import("lit-element").CSSResult;
    src: any;
    iFrame: HTMLIFrameElement;
    webviewId: number;
    constructor();
    connectedCallback(): void;
    disconnectedCallback(): void;
    onFrameLoad(): void;
    sendWebviewId(): void;
    stopSendWebviewIdRecycle(): void;
    clearTimeout(): void;
    syncWebviewTitleToHeader(): void;
    private postMessage;
    sendMessage(data: any): void;
    onRecivedMessgae(data: any): void;
    render(): import("lit-element").TemplateResult;
}
