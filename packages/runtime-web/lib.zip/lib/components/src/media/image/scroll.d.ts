export default class ScrollHelper {
    private callbacks;
    private listener;
    constructor();
    static getInstance(): any;
    getRoot(): Element;
    listenScroll(): void;
    add(element: any, callback: any): void;
    remove(element: any): void;
    destroy(): void;
}
