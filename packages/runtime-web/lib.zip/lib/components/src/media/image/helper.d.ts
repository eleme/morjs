export declare const isElementVisible: (el: any) => boolean;
export declare const outDocument: (el: any, index?: number) => any;
