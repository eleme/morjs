import { BaseElement } from '../../baseElement';
export default class ImageView extends BaseElement {
    static get styles(): import("lit-element").CSSResult;
    src: any;
    mode: string;
    cssText: string;
    state: number;
    /**
     * 支持图片懒加载，不支持通过 css 来控制 image 展示隐藏的场景。
     */
    ['lazy-load']: boolean;
    ['default-source']: string;
    ['drag-able']: string;
    private _isLazyLoad;
    get isLazyLoad(): boolean;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    private onModeChange;
    connectedCallback(): void;
    lazyLoadImage(): void;
    disconnectedCallback(): void;
    private loadImagePromise;
    private loadImage;
    private imageLoadSuccess;
    private imageLoadFail;
    render(): "" | import("lit-element").TemplateResult;
}
