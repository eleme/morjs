import { BaseElement } from '../../baseElement';
declare global {
    class Plyr {
        media: any;
        elements: any;
        source: {
            type: string;
            sources: {
                src: any;
            }[];
            poster: string;
        };
        muted: boolean;
        constructor(target: any, options: Record<string, any>);
    }
}
export default class VideoView extends BaseElement {
    videoId: string;
    svgContainerClass: string;
    videoTarget: any;
    svgContainerTarget: any;
    constructor();
    static get styles(): import("lit-element").CSSResult[];
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    renderVideo(): void;
    renderSvgIcon(types: any): void;
    initControls(): void;
    connectedCallback(): void;
    disconnectedCallback(): void;
    id: string;
    src: any;
    controls: boolean;
    loop: boolean;
    muted: boolean;
    ['show-fullscreen-btn']: boolean;
    ['show-play-btn']: boolean;
    ['show-center-play-btn']: boolean;
    autoPlay: boolean;
    ['initial-time']: number;
    ['object-fit']: string;
    poster: string;
    ['poster-size']: string;
    controlsOption: any[];
    render(): import("lit-element").TemplateResult;
}
