export declare function formatAttributes(curString: any, name: any, val: any, map: any): any;
/**
 * 设置controls工具栏的展示内容
 * @param {boolean} controls 是否展示controls
 * @param {object} otherProps 可自定义项的属性值
 * @returns
 */
export declare function setControls(controls: any, otherProps: any): any[];
/**
 *
 * @param context 上下文
 * @param video 视频示例
 */
export declare function addEvent(context: any, video: any): void;
export declare function initEmptyApi(self: any): void;
export declare function setVideoApi(self: any, video: any): void;
export declare const randomId: () => number;
