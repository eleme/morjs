export declare const VideoStyles: import("lit-element").CSSResult;
