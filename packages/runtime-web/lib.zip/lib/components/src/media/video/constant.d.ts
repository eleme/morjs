export declare const ICON_TYPE: ({
    id: string;
    item: {
        path: string[];
        polygon?: undefined;
    };
} | {
    id: string;
    item: {
        polygon: string[];
        path: string[];
    };
} | {
    id: string;
    item: {
        polygon: string[];
        path?: undefined;
    };
})[];
export declare const CONTROLS_MAP: {
    "show-center-play-btn": string;
    "show-play-btn": string;
    "show-fullscreen-btn": string;
};
export declare const TOTAL_CONTROL: string[];
