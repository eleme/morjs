export declare const PlyrStyles: import("lit-element").CSSResult;
