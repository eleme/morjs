export declare const DEFAULT_CHILDREN_STYLES = "\nflex: 1;\n";
export declare const Styles: import("lit-element").CSSResult;
