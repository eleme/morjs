import { BaseElement } from '../../baseElement';
declare const maskStyle = "mask-style";
declare const maskClass = "mask-class";
declare const indicatorStyle = "indicator-style";
declare const indicatorClass = "indicator-class";
export default class PickerView extends BaseElement {
    startY: number;
    movedY: number;
    lastMovedY: number;
    nodesCache: WeakMap<object, any>;
    [maskStyle]: any;
    [maskClass]: any;
    [indicatorStyle]: any;
    [indicatorClass]: any;
    _class: string;
    _value: any[];
    slotNodes: any;
    static get styles(): import("lit-element").CSSResult;
    attributeChangedCallback(name: any, oldValue: any, newValue: any): void;
    disconnectedCallback(): void;
    initChildrenStyles(): void;
    mapChildNodes(callback: any): void;
    set(node: any, value: any): void;
    dispatch(eventName: any, data: any): void;
    handleChange(e: any): void;
    getSelectValue(): any[];
    render(): import("lit-element").TemplateResult;
}
export {};
