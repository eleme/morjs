export declare const INIT_HEIGHT: number;
export declare const INDICATOR_TOP: number;
export declare const CHILDREN_NAME = "tiga-picker-view-column";
