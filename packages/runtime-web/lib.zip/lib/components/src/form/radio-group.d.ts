import { BaseElement } from '../baseElement';
import { IFormComponent } from './IFormComponent';
export default class RadioGroup extends BaseElement implements IFormComponent {
    selectVal: string;
    /**
     * 组件值，选中时 change 事件会携带的 value。
     */
    onChange: string;
    /**
     * 当前的value
     * 内部变量，暴露给form
     */
    value: string;
    /**
     * 私有属性，当前组件是否受控
     * 默认值：false
     */
    controlled: boolean;
    reset(): void;
    constructor();
    connectedCallback(): void;
    initStatus(): void;
    initTapClick(): void;
    findCheckNode(node: any): any;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    disconnectedCallback(): void;
    changeRadioValue(value: any): void;
    _callTigaRadioGroup: (e: any) => void;
    _initTigaRadioGroup: (e: any) => void;
    addListener(): void;
    render(): import("lit-element").TemplateResult;
}
