import { BaseElement } from '../baseElement';
import { IFormComponent } from './IFormComponent';
export default class Input extends BaseElement implements IFormComponent {
    blurOnClick: boolean;
    syncTimeId: any;
    static get styles(): import("lit-element").CSSResult;
    static get properties(): {
        value: {
            type: StringConstructor;
        };
    };
    placeholder: any;
    controlled: boolean;
    private _value;
    get value(): any;
    set value(v: any);
    get placeholderStyle(): string;
    reset(): void;
    ['is-focus']: boolean;
    maxlength: number;
    type: string;
    password: boolean;
    ['placeholder-style']: string;
    ['selection-start']: number;
    ['selection-end']: number;
    /**
     * H5定制属性，input keydown事件冒泡
     * */
    ['keydown-bubbles']: boolean;
    inputElement: HTMLInputElement;
    onConfirm: any;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    _handleInput(e: any): void;
    syncValueToInput(): void;
    _checkNumberInputMaxLength(): boolean;
    _handleKeyDown(e: any): void;
    connectedCallback(): void;
    private setSelectionRange;
    private onBlur;
    private onFocus;
    render(): import("lit-element").TemplateResult;
}
