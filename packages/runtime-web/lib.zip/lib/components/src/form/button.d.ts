import { BaseElement } from '../baseElement';
import TigaForm from './form';
export default class Button extends BaseElement {
    protected enableHover: boolean;
    static get styles(): import("lit-element").CSSResult;
    loading: boolean;
    ['form-type']: any;
    formtype: any;
    getFormType(): any;
    ['open-type']: any;
    connectedCallback(): void;
    onClicked: () => void;
    protected getForm(): TigaForm | null;
    render(): import("lit-element").TemplateResult;
}
