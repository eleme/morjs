import { BaseElement } from '../baseElement';
export default class Radio extends BaseElement {
    static get styles(): import("lit-element").CSSResult;
    /**
     * 组件值，选中时 change 事件会携带的 value。
     */
    value: string;
    /**
     * 当前是否选中。
     * 默认值：false
     */
    checked: boolean;
    /**
     * 是否禁用。
     */
    disabled: boolean;
    /**
     * radio 的颜色，同 CSS 色值。
     */
    color: string;
    constructor();
    connectedCallback(): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    disconnectedCallback(): void;
    _changeClassList(name: any): void;
    _handleClick(): void;
    renderRadio(): import("lit-element").TemplateResult;
    render(): import("lit-element").TemplateResult;
}
