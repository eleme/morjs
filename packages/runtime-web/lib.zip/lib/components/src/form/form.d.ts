import { BaseElement } from '../baseElement';
export default class TigaForm extends BaseElement {
    form: HTMLFormElement;
    submit(): void;
    reset(): void;
    render(): import("lit-element").TemplateResult;
}
