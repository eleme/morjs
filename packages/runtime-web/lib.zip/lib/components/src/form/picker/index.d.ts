import { BaseElement } from '../../baseElement';
export default class Picker extends BaseElement {
    startY: number;
    movedY: number;
    lastMovedY: number;
    lastIndex: number;
    showPicker: boolean;
    styles: {
        transform: string;
    };
    title: string;
    show: boolean;
    range: any[];
    ['range-key']: string;
    value: number;
    disabled: boolean;
    confirmText: string;
    cancelText: string;
    connectedCallback(): void;
    static get styles(): import("lit-element").CSSResult;
    onPickerClick(): void;
    togglePicker(isShow?: boolean): void;
    onTouchStart(event: any): void;
    onTouchMove(event: any): void;
    onTouchEnd(): void;
    move(moveY?: number): void;
    getClosestIndex(distance: any): number;
    dispatch(eventName: any, data: any): void;
    onConfirm(): void;
    onCancel(): void;
    getName(item: any): any;
    render(): import("lit-element").TemplateResult;
}
