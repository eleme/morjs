export declare const ITEM_HEIGHT: number;
export declare const HEADER_HEIGHT: number;
export declare const CONTENT_HEIGHT: number;
export declare const INDICATOR_TOP: number;
export declare const RATE = 0.4;
