export declare const fixedBody: (document: any) => void;
export declare const looseBody: (document: any) => void;
export declare const getPosition: ({ changedTouches }: {
    changedTouches?: any[];
}) => {
    x: any;
    y: any;
};
export declare const isIos: () => boolean;
