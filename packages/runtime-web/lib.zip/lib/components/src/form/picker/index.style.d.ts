export declare const PickerStyles: import("lit-element").CSSResult;
