import { BaseElement } from '../baseElement';
import { IFormComponent } from './IFormComponent';
export default class Slider extends BaseElement implements IFormComponent {
    static get styles(): import("lit-element").CSSResult;
    /**
     * 组件名字，用于表单提交获取数据。
     */
    name: string;
    /**
     * 最小值。
     * 默认值：0
     */
    min: number;
    /**
     * 最大值。
     * 默认值：1
     */
    max: number;
    /**
     * 步长，值必须大于 0，并可被(max - min)整除。
     * 默认值：1
     */
    step: number;
    /**
     * 是否禁用。
     * 默认值：false
     */
    disabled: boolean;
    /**
     * 当前取值。。
     * 默认值：false
     */
    value: number;
    /**
     * 是否显示当前 value。
     * 默认值：false
     */
    ['show-value']: boolean;
    /**
     * 已选择的颜色，同 CSS 色值。
     * 默认值：#108ee9
     */
    ['activeColor']: string;
    /**
     * 背景条颜色，同 CSS 色值。
     * 默认值：#ddd
     */
    ['backgroundColor']: string;
    /**
     * 轨道线条高度。
     * 默认值：4
     */
    ['track-size']: number;
    /**
     * 滑块大小。
     * 默认值：22
     */
    ['handle-size']: number;
    /**
     * 滑块填充色，同 CSS 色值。
     * 默认值：#fff
     */
    ['handle-color']: string;
    /**
     * onChange EventHandle 完成一次拖动后触发，event.detail = {value: value}。
     */
    /**
     * onChanging EventHandle 拖动过程中触发的事件，event.detail = {value: value}。
     */
    /**
     * 起始位置
     */
    startX: number;
    /**
     * 线条长度
     * 私有变量
     */
    lineLength: number;
    /**
     * 百分比
     * 私有变量
     */
    percent: number;
    /**
     * 手柄位置
     * 私有变量
     */
    handlePox: number;
    reset(): void;
    constructor();
    private _handleTouchStart;
    private _handleTouchEnd;
    private parsePercentVal;
    private _handleTouchMove;
    private getClientRect;
    checkBoundingRectPox(position: any): any;
    tapChangingEvent(): void;
    tapChangeEvent(): void;
    connectedCallback(): void;
    _init(): void;
    render(): import("lit-element").TemplateResult;
}
