export interface IFormComponent {
    value: any;
    reset?: () => void;
}
