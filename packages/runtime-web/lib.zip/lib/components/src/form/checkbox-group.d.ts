import { BaseElement } from '../baseElement';
import { IFormComponent } from './IFormComponent';
export default class CheckboxGroup extends BaseElement implements IFormComponent {
    /**
     * 组件值，选中时 change 事件会携带的 value。
     */
    onChange: string;
    selectValues: any[];
    /**
     * 当前的value
     * 内部变量，暴露给form
     */
    value: string;
    reset(): void;
    constructor();
    connectedCallback(): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    disconnectedCallback(): void;
    initTapClick(): void;
    findCheckNode(node: any): any;
    _callTigaCheckboxGroup: (e: any) => void;
    _initTigaCheckboxGroup: () => void;
    addListener(): void;
    changeValueList(value: any): void;
    render(): import("lit-element").TemplateResult;
}
