import { BaseElement } from '../baseElement';
import { IFormComponent } from './IFormComponent';
export default class Textarea extends BaseElement implements IFormComponent {
    blurOnClick: boolean;
    static get styles(): import("lit-element").CSSResult;
    placeholder: any;
    value: any;
    ['is-focus']: boolean;
    ['show-count']: boolean;
    ['auto-height']: boolean;
    maxlength: number;
    type: string;
    onConfirm: any;
    inputElement: HTMLInputElement;
    countWrapElement: HTMLParagraphElement;
    text: string;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    showCountChanged(): void;
    _handleInput(e: any): void;
    _handleKeyDown(e: any): void;
    connectedCallback(): void;
    /**
     * 自适应高度。参考：https://segmentfault.com/a/1190000022272721
     */
    private _updateHeight;
    private _updateCountWrapText;
    render(): import("lit-element").TemplateResult;
}
