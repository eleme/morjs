import { BaseElement } from '../baseElement';
export default class Label extends BaseElement {
    static get styles(): import("lit-element").CSSResult;
    /**
     * 绑定组件的 ID。
     */
    for: string;
    constructor();
    connectedCallback(): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    disconnectedCallback(): void;
    render(): import("lit-element").TemplateResult;
}
