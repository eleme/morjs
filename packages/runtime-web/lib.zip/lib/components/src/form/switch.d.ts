import { BaseElement } from '../baseElement';
import { IFormComponent } from './IFormComponent';
export default class Switch extends BaseElement implements IFormComponent {
    static get styles(): import("lit-element").CSSResult;
    /**
     * 组件名字，用于表单提交获取数据。
     */
    name: string;
    /**
     * 当前是否选中。
     * 默认值：false
     */
    checked: boolean;
    /**
     * 是否禁用。
     * 默认值：6
     */
    disabled: boolean;
    /**
     * 组件颜色，同 CSS 色值。
     */
    color: string;
    /**
     * onChange checked 改变时触发，event.detail={ value:checked}。
     */
    /**
     * controlled 是否为受控组件，为 true 时，checked 会完全受 setData 控制。
     */
    get value(): boolean;
    reset(): void;
    constructor();
    connectedCallback(): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    disconnectedCallback(): void;
    _handleClick(): void;
    render(): import("lit-element").TemplateResult;
}
