export declare const fixedBody: (document: any) => void;
export declare const looseBody: (document: any) => void;
export declare const getPosition: ({ changedTouches, x, y }: {
    changedTouches?: any[];
    x?: number;
    y?: number;
}) => {
    x: any;
    y: any;
};
