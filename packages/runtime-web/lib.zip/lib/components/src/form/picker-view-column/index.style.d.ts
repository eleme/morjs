export declare const DEFAULT_ITEM_STYLES = "\n  display: block;\n  text-align: center;\n";
export declare const Styles: import("lit-element").CSSResult;
