import { LitElement } from 'lit-element';
export declare class BaseElement extends LitElement {
    private hoverTouchStartHandler;
    private hoverTouchEndHandler;
    constructor();
    private eventListenerMap;
    private longTimeId;
    /**
     * 点击的时候是否执行blue
     */
    protected blurOnClick: boolean;
    /**
     * 是否启用hover功能
     */
    protected enableHover: boolean;
    disabled: boolean;
    ['hover-class']: string;
    customAnimation: any;
    /**
     * tag获得焦点，与tabindex配合使用，为避免与focus方法重名，取名tigaFocus
     */
    tigaFocus: boolean;
    attributeChangedCallback(name: any, oldvalue: any, newvalue: any): void;
    /**
     * 触摸事件
     */
    private handleTouchEvent;
    private handleTouchEventMobile;
    /**
     * 鼠标事件
     * @param e
     */
    private handleMouseEvent;
    /**
     * 防止因为setData 导致多次注册事件。
     */
    private mobileTouchEventCache;
    addEventListener(type: any, callback: any, options?: any): void;
    private mergeFunc;
    connectedCallback(): void;
    disconnectedCallback(): void;
    private canHandleTap;
    private startTouch;
    private moveTouch;
    _handleClickedStart: (e: TouchEvent) => void;
    _handleClickedMove: (e: TouchEvent) => void;
    private riaseTapEvent;
    _handleClickedEnd: (e: Event) => void;
    private _onTouchStart;
    private _onTouchEnd;
    /**
     * 进入hover 状态
     */
    protected onHoverIn(): void;
    /**
     * 离开hover 状态
     */
    protected onHoverOut(): void;
}
