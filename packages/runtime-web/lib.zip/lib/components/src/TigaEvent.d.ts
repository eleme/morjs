export interface TigaEventInit<T = any> extends EventInit {
    detail?: T;
    other?: object;
}
export declare class TiGaEvent<T> extends Event {
    detail: T;
    other: object;
    constructor(typeArg: string, eventInitDict?: TigaEventInit<T>);
}
