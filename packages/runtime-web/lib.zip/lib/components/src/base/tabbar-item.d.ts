import { BaseElement } from '../baseElement';
export default class TabbarItem extends BaseElement {
    badgeStyle: any;
    dotStyle: any;
    constructor();
    static get styles(): import("lit-element").CSSResult;
    key: any;
    isSelected: boolean;
    text: string;
    icon: string;
    badgeText: string;
    showRedDot: string;
    textColor: string;
    disableSafeAreaPadding: boolean;
    handleClick(): void;
    render(): import("lit-element").TemplateResult;
}
