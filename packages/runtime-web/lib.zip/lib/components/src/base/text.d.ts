import { BaseElement } from '../baseElement';
export default class Text extends BaseElement {
    static get styles(): import("lit-element").CSSResult;
    /**
     * 显示的行数
     */
    ['number-of-lines']: number;
    /**
     * 是否可选择
     */
    selectable: boolean;
    attributeChangedCallback(name: string, oldVal: any, newVal: any): void;
    connectedCallback(): void;
    numberOfLinesChanged(): void;
    selectableChanged(): void;
    render(): import("lit-element").TemplateResult;
}
