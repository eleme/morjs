import { BaseElement } from '../baseElement';
export default class RichText extends BaseElement {
    static get styles(): import("lit-element").CSSResult;
    /**
     * nodes 节点
     */
    nodes: any[];
    constructor();
    connectedCallback(): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    disconnectedCallback(): void;
    getNodeProps(node: any, tagName: any): any;
    parseNodes(nodes: any): any;
    parseHtmlTag(tagName: any, props: any, children: any): any;
    parseStyleMap(style?: string): {};
    parseClassMap(className?: string): {};
    renderContent(): any;
    render(): import("lit-element").TemplateResult;
}
