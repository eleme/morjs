import { BaseElement } from '../baseElement';
export default class Navigator extends BaseElement {
    static get styles(): import("lit-element").CSSResult;
    /**
     * 跳转方式。
     */
    ['open-type']: string;
    /**
     * 当前小程序内的跳转链接。
     */
    url: any;
    connectedCallback(): void;
    private handleTap;
    render(): import("lit-element").TemplateResult;
}
