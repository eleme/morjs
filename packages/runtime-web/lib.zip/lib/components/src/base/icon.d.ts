import { BaseElement } from '../baseElement';
export default class Icon extends BaseElement {
    private ICON_TYPE;
    static get styles(): import("lit-element").CSSResult;
    /**
     * icon 类型，有效值： info、warn、waiting、cancel、download、search、clear、success、success_no_circle、loading。
     */
    type: string;
    /**
     * icon 大小，单位 px。
     * 默认值：23
     */
    size: number;
    /**
     * icon 颜色，同 CSS 色值。
     */
    color: string;
    paths: any[];
    constructor();
    connectedCallback(): void;
    renderSvgIcon(): void;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    disconnectedCallback(): void;
    render(): import("lit-element").TemplateResult;
}
