import { BaseElement } from '../baseElement';
export default class Progress extends BaseElement {
    static get styles(): import("lit-element").CSSResult;
    /**
     * 显示百分比
     * 0~100
     */
    percent: number;
    /**
     * 右侧显示百分比值
     * 默认值：show-info="{{false}}"
     */
    ['show-info']: boolean;
    /**
     * 线的粗细，单位 px
     * 默认值：6
     */
    ['stroke-width']: number;
    /**
     * 进度条颜色
     * 默认值：#09BB07
     */
    ['active-color']: string;
    /**
     * 未选择的进度条颜色。
     */
    ['background-color']: string;
    /**
     * 是否添加从 0% 开始加载的入场动画。
     * 默认值：active="{{false}}"
     */
    active: boolean;
    constructor();
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
    disconnectedCallback(): void;
    render(): import("lit-element").TemplateResult;
}
