export declare function rpxToRem(rpxValue: number): string;
