declare const _default: {
    setNavigationBar({ title, image, backgroundColor, borderBottomColor, reset }: {
        title: any;
        image: any;
        backgroundColor: any;
        borderBottomColor: any;
        reset: any;
    }): Promise<unknown>;
    getTitleColor(): Promise<unknown>;
    showNavigationBarLoading(): Promise<unknown>;
    hideNavigationBarLoading(): Promise<unknown>;
    hideBackHome(): void;
};
export default _default;
