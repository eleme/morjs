declare const _default: {
    pageScrollTo({ scrollTop, duration, selector }: {
        scrollTop: any;
        duration?: number;
        selector: any;
    }): Promise<unknown>;
};
export default _default;
