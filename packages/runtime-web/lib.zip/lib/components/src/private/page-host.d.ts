import { LitElement } from 'lit-element';
import { IPageConfig, IPageHost } from './IPage';
declare enum PullRefreshState {
    Normal = 0,
    Pulling = 1,
    WillRefresh = 2,
    Refreshing = 3
}
export default class PageHost extends LitElement implements IPageHost {
    static get styles(): import("lit-element").CSSResult;
    static get properties(): {
        pullRefreshState: {
            type: NumberConstructor;
        };
    };
    get isAutoTransparent(): boolean;
    private config;
    headerOpacity: number;
    contentElement: HTMLDivElement;
    ['show-header']: boolean;
    ['show-back']: boolean;
    ['title-bar-height']: string;
    ['status-bar-height']: number;
    /**
     * 注意释放
     */
    private styleElement;
    setConfig(config: IPageConfig): void;
    getConfig(): IPageConfig;
    connectedCallback(): void;
    disconnectedCallback(): void;
    private canHandleReachBottom;
    private onScroll;
    /**
     * 是否启用下拉刷新功能
     */
    enbalePullRefresh: boolean;
    private lastTouchPoint;
    private _pullRefreshState;
    get pullRefreshState(): PullRefreshState;
    set pullRefreshState(value: PullRefreshState);
    startPullDownRefresh(): void;
    stopPullDownRefresh(): void;
    private animationPaddingTop;
    onTouchMove: (e: TouchEvent) => void;
    onTouchEnd: () => void;
    private headerLoading;
    showNavigationBarLoading(): void;
    hideNavigationBarLoading(): void;
    private getPullRefrehHeader;
    private getRenderHeader;
    render(): import("lit-element").TemplateResult;
}
export {};
