export declare const TransparentHeaderDefaultOpacity = 0;
export declare const TRANSPARENT: {
    NONE: string;
    ALWAYS: string;
    AUTO: string;
};
export declare const BOOLEAN: {
    YES: string;
    NO: string;
};
export declare const COLOR: {
    WHITE: string;
    BLACK: string;
    TRANSPARENT: string;
};
