export declare const Styles: import("lit-element").CSSResult;
