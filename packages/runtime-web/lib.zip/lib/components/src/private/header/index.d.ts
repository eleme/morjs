import { LitElement } from 'lit-element';
export default class Header extends LitElement {
    static get styles(): import("lit-element").CSSResult;
    ['default-title']: string;
    ['transparent-title']: any;
    ['title-image']: any;
    ['border-bottom-color']: any;
    ['title-penetrate']: any;
    ['show-back']: any;
    ['title-bar-color']: any;
    ['header-opacity']: any;
    ['title-bar-height']: any;
    ['status-bar-height']: any;
    ['header-loading']: any;
    getHeaderConfig(): {
        isAlways: boolean;
        isAutoTransparentTitle: boolean;
        titleBarColor: any;
        titleColor: string;
        isOpenPenetrate: boolean;
        isDefaultOpacity: boolean;
        styles: {
            titleBarHeight: string;
            titleBarLineHeight: string;
            statusBarHeight: string;
        };
    };
    private getHeaderLoadingRender;
    render(): import("lit-element").TemplateResult;
}
