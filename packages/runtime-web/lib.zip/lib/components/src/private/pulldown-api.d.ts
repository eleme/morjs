import PageHost from './page-host';
export declare function getPage(): PageHost;
declare const _default: {
    startPullDownRefresh(): Promise<unknown>;
    stopPullDownRefresh(): Promise<unknown>;
    setCanPullDown({ canPullDown }: {
        canPullDown: any;
    }): void;
};
export default _default;
