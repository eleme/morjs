/**
 * 页面触发下拉刷新
 */
export declare const PullDownRefreshEventName = "pagepulldownrefresh";
/**
 * 页面滚动到底部事件
 */
export declare const ReachBottomEventName = "pagereachbottom";
/**
 * 页面滚动事件
 */
export declare const ScrollEventName = "pagescroll";
export interface IPageConfig {
    defaultTitle?: string;
    showTitleLoading?: boolean;
    transparentTitle?: string;
    titleImage?: string;
    titleBarColor?: string;
    backgroundColor?: string;
    borderBottomColor?: string;
    backgroundImageColor?: string;
    onReachBottomDistance?: number;
    titlePenetrate?: 'YES' | 'NO';
}
/**
 * 默认的页面配置
 */
export declare const DefualtPageConfig: IPageConfig;
export interface IPageHost {
    enbalePullRefresh: boolean;
    setConfig(config: IPageConfig): any;
    startPullDownRefresh(): any;
    stopPullDownRefresh(): any;
}
