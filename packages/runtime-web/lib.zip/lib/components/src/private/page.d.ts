import { LitElement } from 'lit-element';
export default class Page extends LitElement {
    static get styles(): import("lit-element").CSSResult;
    render(): import("lit-element").TemplateResult;
}
