import './src/base/tabbar';
import './src/base/tabbar-item';
import './src/private/index';
import './src/private/page';
